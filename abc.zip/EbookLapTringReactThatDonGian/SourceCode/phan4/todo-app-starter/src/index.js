import React from "react";
import ReactDOM from "react-dom";

const element = <h1>Hello from VNTALKING</h1>;

ReactDOM.render(element, document.getElementById("root"));