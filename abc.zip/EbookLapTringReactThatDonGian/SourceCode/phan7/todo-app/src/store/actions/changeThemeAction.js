export const saveTheme = color => ({
    type: "CHANGE_THEME",
    payload: {
        color
    }
});
